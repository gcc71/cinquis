def main():
    print('cinquis test')


if __name__ == "__main__":
    main()
